import React from "react";
import "./Diaryheader.css";
function Diaryheader() {
    return (
        <div className="header">
            <h1> 아무말 작성기 마음을 비워요 ✍</h1>
        </div>
    )
};

export default Diaryheader;